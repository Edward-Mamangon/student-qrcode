<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generate QR Code Modal</title>
  <script src="qrcode.min.js"></script>
  <style>
    #QRImage{
      padding: 10px;
      background-color: white;
    }
  </style>

</head>
<body>
  

<!------- FOR EDIT BUTTON ---------->
<!-- Modal -->
<div class="modal fade" id="viewqrcode" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Student Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="form-group">
          <label for="">ID Number</label>
          <input type="text" name="idnumber" id="idnumber2" class="form-control" readonly>
        </div>

        <div class="form-group">
          <label for="">Full Name</label>
          <input type="text" name="fname" id="fname2" class="form-control" readonly><br>
        </div>

        <div class="form-group">
          <button type="submit" name="btnGenerate" id="btnGenerate" class="btn btn-success" onclick="generate()">Generate QR</button><br>
        </div>

        <!-- <div id="qrbox" style="text-align: center;">
          <img src="generate.php?text=<?php echo $_GET['idnumber']?>" >
        </div> -->

        <div class="QRImage-wrapper">
          <div id="QRImage"></div>
        </div>
        <!-- <div class="modal-footer">
          <button type="submit" name="update" class="btn btn-primary">UPDATE DATA</button>
        </div> -->
      </div>
    </div>
  </div>
</div>



  <script>
        var idNum2 = document.getElementById("idnumber2");
        var QRImage = document.getElementById("QRImage");

        var NewImage = new QRCode(QRImage, {
            width: 200,
            height: 200
        });

        function generate() {
            var data = idNum2.value;
            // alert("QR code for Student: "+ data +" "+"successfully created.");
            NewImage.makeCode(data);
        }
  </script>
</body>
</html>