<?php

session_start();
if (!isset($_SESSION['user_name'])) {
  header("Location: index.php");
}

include 'includes/header.php';
include 'includes/sidebar.php';

$conn = mysqli_connect("localhost", "root", "", "student-qrcode_db");

if (isset($_POST['generateReport'])) {
    // $name = $_POST['name'];
    $grade = $_POST['grade'];
    $section = $_POST['section'];
    // $subject = $_POST['subject'];

    // $queryAttendance = "SELECT s.idnumber, s.fname, s.mname, s.lname, s.grade, s.section, ca.date
    //                      FROM student_tbl AS s
    //                      LEFT JOIN 
    //                      WHERE grade = '$grade' AND section = '$section' ";
    $queryAttendance = "INSERT INTO 
                        SELECT s.idnumber, s.fname, s.mname, s.lname, s.grade, s.section, ca.date
                        FROM student_tbl AS s
                        LEFT JOIN 
                        WHERE grade = '$grade' AND section = '$section' ";
    $result = mysqli_query($conn, $queryAttendance);
    // mysqli_fetch_assoc($sqlReport) will populate the $row var
    // $row = mysqli_fetch_assoc($result);
}
?>

<div class="content-wrapper">
    <h2>Student Attendance Report</h2>

    <form action="report.php" method="post">
        <!-- ============Filter By Teacher Select======================== -->
        <div class="form-group">
            <?php 
                $query_teachers = 'SELECT * FROM teacher_tbl'; 
                $res = mysqli_query($conn, $query_teachers);
            ?>

            <?php echo '<select class="form-control" name="name" aria-label="Default select example" >'; ?>
                <option disabled selected>Filter by Teacher</option>
            <?php while (($row = mysqli_fetch_assoc($res)) > 0) { ?>
            
                <option value="<?php echo $row['name'] ?> "> <?php echo $row['name']; ?></option>
            <?php  }
                echo '</select>'; 
            ?>
        </div>

        <!-- ============Filter By Teacher Grade Level ======================== -->
        <div class="form-group">
            <?php 
                $query_grades = 'SELECT * FROM student_tbl GROUP BY grade'; 
                $res = mysqli_query($conn, $query_grades);
            ?>

            <?php echo '<select class="form-control" name="grade" aria-label="Default select example" >'; ?>
                <option disabled selected>Filter by Grade</option>
            <?php while (($row = mysqli_fetch_assoc($res)) > 0) { ?>
            
                <option value="<?php echo $row['grade'] ?> "> <?php echo $row['grade']; ?></option>
            <?php  }
                echo '</select>'; 
            ?>
        </div>

        <!-- ============Filter By Section Level ======================== -->
        <div class="form-group">
            <?php 
                $query_section = 'SELECT * FROM student_tbl GROUP BY section'; 
                $res = mysqli_query($conn, $query_section);
            ?>

            <?php echo '<select class="form-control" name="section" aria-label="Default select example" >'; ?>
                <option disabled selected>Filter by Section</option>
            <?php while (($row = mysqli_fetch_assoc($res)) > 0) { ?>
            
                <option value="<?php echo $row['section'] ?> "> <?php echo $row['section']; ?></option>
            <?php  }
                echo '</select>'; 
            ?>
        </div>

        <!-- ============Filter By Subject ======================== -->
        <div class="form-group">
            <?php 
                $query_subjects = 'SELECT * FROM subject_tbl'; 
                $res = mysqli_query($conn, $query_subjects);
            ?>

            <?php echo '<select class="form-control" name="subject" aria-label="Default select example" >'; ?>
                <option disabled selected>Filter by Subject</option>
            <?php while (($row = mysqli_fetch_assoc($res)) > 0) { ?>
            
                <option value="<?php echo $row['subject'] ?> "> <?php echo $row['subject']; ?></option>
            <?php  }
                echo '</select>'; 
            ?>
        </div>

        <!-- Generate Report Button -->
        <div class="form-group">
            <button style="margin-bottom: 10px;" type="submit" name="generateReport" class="btn btn-success" >
                Check Attendance
            </button>
            <!-- <input type="submit" name="generateReport" value="Generate Report"> -->
        </div>
    </form>

    <!-- ====================== Table Section ================================== -->
    <table id="datatable_id" class="table table-bordered" id="dataTable" width="100%" cellspacing="0" >
        <thead>
          <tr>
            <th>ID Number</th>
            <th>First Name</th>
            <th>Middle Name</th>
            <th>Last Name</th>
            <th>Grade</th>
            <th>Section</th>
            <th>Date</th>
            <th>Mark</th>
          </tr>
        </thead>
        <tbody>
        
        <?php
            if(mysqli_num_rows($result) > 0) {        
              while ($row = mysqli_fetch_assoc($result)) {
        ?>

          <tr>
            <td><?php echo $row['idnumber']; ?> </td>
            <!-- <a class="viewqr" type="submit" name="submitqr"> <span class="fa fa-qrcode" style="cursor: pointer;"></span></a></td> -->
            <td><?php echo $row['fname']; ?></td>
            <td><?php echo $row['mname']; ?></td>
            <td><?php echo $row['lname']; ?></td>
            <td><?php echo $row['grade']; ?></td>
            <td><?php echo $row['section']; ?></td>
            <td></td>
            <td></td>
          </tr>
          <?php
              }

            }else{
                echo "No Record Found!";
            }
        ?>

        </tbody>
      </table>

</div>

<?php
    include 'includes/footer.php';
?>


